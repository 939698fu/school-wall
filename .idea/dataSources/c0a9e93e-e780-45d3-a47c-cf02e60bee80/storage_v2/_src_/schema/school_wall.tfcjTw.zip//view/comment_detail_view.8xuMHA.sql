create definer = root@localhost view comment_detail_view as
select `c`.`id`          AS `id`,
       `c`.`post_id`     AS `post_id`,
       `c`.`user_id`     AS `user_id`,
       `c`.`content`     AS `content`,
       `c`.`likes`       AS `likes`,
       `c`.`create_time` AS `create_time`,
       `c`.`update_time` AS `update_time`,
       `u`.`nickname`    AS `author_nickname`,
       `u`.`avatar`      AS `author_avatar`
from (`school_wall`.`comment` `c` left join `school_wall`.`user` `u` on ((`c`.`user_id` = `u`.`id`)));

-- comment on column comment_detail_view.id not supported: 评论ID

-- comment on column comment_detail_view.post_id not supported: 帖子ID

-- comment on column comment_detail_view.user_id not supported: 评论者ID

-- comment on column comment_detail_view.content not supported: 评论内容

-- comment on column comment_detail_view.likes not supported: 点赞数

-- comment on column comment_detail_view.create_time not supported: 创建时间

-- comment on column comment_detail_view.update_time not supported: 更新时间

-- comment on column comment_detail_view.author_nickname not supported: 用户昵称

-- comment on column comment_detail_view.author_avatar not supported: 头像URL

