create definer = root@localhost view post_detail_view as
select `p`.`id`          AS `id`,
       `p`.`user_id`     AS `user_id`,
       `p`.`title`       AS `title`,
       `p`.`content`     AS `content`,
       `p`.`images`      AS `images`,
       `p`.`tag`         AS `tag`,
       `p`.`tag_color`   AS `tag_color`,
       `p`.`is_anon`     AS `is_anon`,
       `p`.`is_private`  AS `is_private`,
       `p`.`likes`       AS `likes`,
       `p`.`comments`    AS `comments`,
       `p`.`create_time` AS `create_time`,
       `p`.`update_time` AS `update_time`,
       `u`.`nickname`    AS `author_nickname`,
       `u`.`avatar`      AS `author_avatar`
from (`school_wall`.`post` `p` left join `school_wall`.`user` `u` on ((`p`.`user_id` = `u`.`id`)));

-- comment on column post_detail_view.id not supported: 帖子ID

-- comment on column post_detail_view.user_id not supported: 作者ID

-- comment on column post_detail_view.title not supported: 帖子标题

-- comment on column post_detail_view.content not supported: 帖子内容

-- comment on column post_detail_view.images not supported: 图片URL列表，JSON格式

-- comment on column post_detail_view.tag not supported: 话题标签

-- comment on column post_detail_view.tag_color not supported: 标签颜色

-- comment on column post_detail_view.is_anon not supported: 是否匿名(0-否,1-是)

-- comment on column post_detail_view.is_private not supported: 是否仅自己可见(0-否,1-是)

-- comment on column post_detail_view.likes not supported: 点赞数

-- comment on column post_detail_view.comments not supported: 评论数

-- comment on column post_detail_view.create_time not supported: 创建时间

-- comment on column post_detail_view.update_time not supported: 更新时间

-- comment on column post_detail_view.author_nickname not supported: 用户昵称

-- comment on column post_detail_view.author_avatar not supported: 头像URL

